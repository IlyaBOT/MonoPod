#include "SyncFiles.h"
#include "Library.h"
#include "Theme.h"
#include "Display.h"
#include "Settings.h"
#include "ClockService.h"
#include "MonoPodDB.h"
#include "FastCrc32.h"
#include "BufferedSdWrite.h"
#include <WiFi.h>
#include <esp_heap_caps.h>
namespace SyncFiles {
String error;
namespace {
const char* PART="/.monopod-transfer.part";
const char* BACKUP="/.monopod-transfer.bak";
const char* JOURNAL="/.monopod-transfer.target";
File output;String target;uint32_t expected=0,checksum=0,received=0,runningCRC=~0u,lastWrite=0;
bool active=false,isTheme=false;
// 16KiB internal DRAM (prefer DMA-accessible RAM over PSRAM for SD SPI).
// Fallback to 8/4KiB, then zero-copy direct writes if memory is exhausted.
constexpr size_t kPreferredWriteBuffer = 16 * 1024;
uint8_t* writeStorage = nullptr;
BufferedSdWrite::Buffer bufferedWrite;
uint32_t transferStartedMs=0;
uint64_t writeTimeUs=0, crcTimeUs=0, flushTimeUs=0;
uint32_t sdWriteCalls=0;
void freeWriteBuffer(){
 bufferedWrite.reset(nullptr,0);
 if(writeStorage){free(writeStorage);writeStorage=nullptr;}
}
void initWriteBuffer(){
 freeWriteBuffer();
 static constexpr size_t kCandidates[]={kPreferredWriteBuffer,8192,4096};
 for(size_t size: kCandidates) {
  // SPI DMA must not rely on a PSRAM-backed source buffer.
  writeStorage=(uint8_t*)heap_caps_malloc(size,MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if(writeStorage){bufferedWrite.reset(writeStorage,size);break;}
 }
}
size_t timedSdWrite(const uint8_t* data,size_t count){
 const uint32_t started=micros();
 const size_t wrote=output.write(data,count);
 writeTimeUs+=(uint32_t)(micros()-started);
 ++sdWriteCalls;
 return wrote;
}
bool flushPending(){
 return bufferedWrite.flush([](const uint8_t* data,size_t n){return timedSdWrite(data,n);});
}
void reportTransfer(const char* status){
 const uint32_t ms=(uint32_t)(millis()-transferStartedMs);
 // Wall clock includes HTTP receiving/parsing and SD latency, not just SPI.
 const uint32_t kibps=ms? (uint32_t)(((uint64_t)received*1000ULL)/(1024ULL*ms)):0;
 MONOPOD_LOG.printf("[SYNC PERF] %s bytes=%lu wall=%lu ms speed=%lu KiB/s sd=%llu us (%lu calls) crc=%llu us flush=%llu us buffer=%u B\n",
  status,(unsigned long)received,(unsigned long)ms,(unsigned long)kibps,
  (unsigned long long)writeTimeUs,(unsigned long)sdWriteCalls,
  (unsigned long long)crcTimeUs,(unsigned long long)flushTimeUs,
  (unsigned)bufferedWrite.capacity());
}
bool fail(const char* text){error=text;return false;}
bool protectedRoot(String p){p.toLowerCase();return p=="/"||p=="/music"||p=="/playlists"||p=="/themes"||p=="/monopod";}
String number(uint64_t n){char buf[24];snprintf(buf,sizeof(buf),"%llu",(unsigned long long)n);return String(buf);}
String entry(File& f,const String& path){uint32_t modified=(uint32_t)f.getLastWrite();bool valid=MonoPodDB::validTime(modified);return "{\"name\":"+quote(path.substring(path.lastIndexOf('/')+1))+",\"path\":"+quote(path)+",\"directory\":"+(f.isDirectory()?"true":"false")+",\"size\":"+number(f.size())+",\"modified\":"+number(valid?modified:0)+",\"modified_valid\":"+(valid?"true":"false")+"}";}
}
uint32_t crcStep(uint32_t c,const uint8_t* b,size_t n){return FastCrc32::update(c,b,n);}
String quote(const String& s){String out="\"";for(size_t i=0;i<s.length();i++){uint8_t c=s[i];if(c=='"'||c=='\\'){out+='\\';out+=(char)c;}else if(c<32){char h[7];snprintf(h,sizeof(h),"\\u%04x",c);out+=h;}else out+=(char)c;}return out+'"';}
bool canonical(const String& in,String& out,bool theme){
 out="";if(in.isEmpty()||in[0]!='/'||in.length()>240)return fail("INVALID_PATH");
 int start=1;out="/";
 while(start<(int)in.length()){
  int end=in.indexOf('/',start);if(end<0)end=in.length();String part=in.substring(start,end);start=end+1;
  if(part.isEmpty())continue;
  if(part=="."||part==".."||part[0]=='.'||part.endsWith(".")||part.endsWith(" ")||part.length()>90)return fail("INVALID_PATH");
  for(size_t i=0;i<part.length();i++){uint8_t c=part[i];if(c<32||c==127||strchr("\\:<>\"|*?",c))return fail("INVALID_PATH");}
  if(out.length()>1)out+='/';out+=part;
 }
 String low=out;low.toLowerCase();
 // Explicit user media asset; permit generic USB/Wi-Fi file upload and download.
 // Keep theme.mpt and other /MonoPod private files behind their own APIs.
 if(low=="/monopod" || low=="/monopod/badapple.bav")return true;
 if(theme && low=="/monopod/theme.mpt")return true;
 if(low=="/monopod"||low.startsWith("/monopod/")||low=="/ipod_control"||low.startsWith("/ipod_control/")||low.startsWith("/system volume information")||low.startsWith("/$recycle.bin")||low.startsWith("/recycler"))return fail("PROTECTED_PATH");
 return true;
}
String fromHex(const String& s){if(s.length()%2||s.length()>480)return "";String out;for(size_t i=0;i<s.length();i+=2){char a=s[i],b=s[i+1];auto digit=[](char c)->int {if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};int x=digit(a),y=digit(b);if(x<0||y<0||!(x*16+y))return "";out+=(char)(x*16+y);}return out;}
bool gate(SyncTransport who){error="";if(!media.sdOK())return fail("NO_SD");if(!syncMode.canWrite(who))return fail("SYNC_REQUIRED");return true;}
String info(){
 String mode=syncMode.is(SyncTransport::UsbCdc)?"usb":syncMode.is(SyncTransport::WiFi)?"wifi":"none";
 uint64_t total=media.sdOK()?media.totalBytes():0,used=media.sdOK()?media.usedBytes():0;
 String formats="[\".mp3\",\".wav\"";
#if FEATURE_FLAC
 formats+=",\".flac\"";
#endif
#if FEATURE_AAC
 formats+=",\".aac\"";
#endif
 formats+="]";
 return "{\"firmware\":\"0.10.7.5\",\"protocol\":4,\"sd_ready\":"+String(media.sdOK()?"true":"false")+",\"total_bytes\":"+number(total)+",\"free_bytes\":"+number(total>=used?total-used:0)+",\"tracks\":"+String((unsigned)media.size())+",\"sync_mode\":"+quote(mode)+",\"ip\":"+quote(WiFi.status()==WL_CONNECTED?WiFi.localIP().toString():WiFi.softAPIP().toString())+",\"font_smoothing\":"+String(settings.data.fontSmoothing?"true":"false")+",\"ntp_enabled\":"+String(clockService.ntpEnabled()?"true":"false")+",\"ntp_server\":"+quote(clockService.ntpServer())+",\"timezone\":"+quote(clockService.timezone())+",\"clock_unix\":"+number(clockService.valid()?(uint64_t)time(nullptr):0)+",\"audio_formats\":"+formats+",\"capabilities\":[\"clock_sync\",\"ntp\",\"ntp_server\",\"list\",\"stat\",\"read\",\"fs_upload\",\"upload\",\"delete\",\"mkdir\",\"rename\",\"theme\",\"theme_get\",\"scan\",\"metadata_ranges\",\"smoothing\",\"sync_end\",\"ota_update_v1\",\"library_db_v1\",\"library_refresh\"]}";
}
String stat(const String& path,SyncTransport who){String p;if(!gate(who)||!canonical(path,p,path=="/MonoPod/theme.mpt"))return "";File f=SD.open(p.c_str());if(!f){fail("NOT_FOUND");return "";}String result=entry(f,p);f.close();return result;}
String list(const String& path,uint32_t offset,uint16_t limit,SyncTransport who){
 String p;if(!gate(who)||!canonical(path,p))return "";if(!limit||limit>32){fail("INVALID_LIMIT");return "";}File d=SD.open(p.c_str());if(!d||!d.isDirectory()){if(d)d.close();fail("NOT_DIRECTORY");return "";}
 String result="{\"entries\":[";uint32_t seen=0;uint16_t count=0;bool more=false;
 File f=d.openNextFile();while(f){String name=f.name();name=name.substring(name.lastIndexOf('/')+1);String full=(p=="/"?"/":p+"/")+name,checked;
  if(canonical(full,checked)){if(seen++>=offset){if(count==limit){more=true;f.close();break;}if(count++)result+=',';result+=entry(f,full);}}
  f.close();f=d.openNextFile();yield();
 }d.close();error="";result+="],\"next\":";result+=more?String(offset+count):String("-1");return result+"}";
}
bool read(const String& path,uint32_t offset,uint8_t* buffer,size_t count,size_t& got,SyncTransport who){String p;got=0;if(!gate(who)||!canonical(path,p,path=="/MonoPod/theme.mpt"))return false;if(count>65536)return fail("INVALID_COUNT");File f=SD.open(p.c_str());if(!f)return fail("NOT_FOUND");if(f.isDirectory()||offset>f.size()){f.close();return fail("INVALID_RANGE");}if(offset==f.size()){f.close();return true;}if(!f.seek(offset)){f.close();return fail("SEEK_FAILED");}size_t n=min(count,(size_t)(f.size()-offset));int actual=f.read(buffer,n);f.close();if(actual<0||(size_t)actual!=n)return fail("SD_READ");got=n;return true;}
bool mkdir(const String& path,SyncTransport who){String p;if(!gate(who)||active||!canonical(path,p))return false;if(SD.exists(p.c_str()))return fail("ALREADY_EXISTS");return SD.mkdir(p.c_str())||fail("MKDIR_FAILED");}
bool remove(const String& path,bool directory,SyncTransport who){String p;if(!gate(who)||active||!canonical(path,p))return false;if(protectedRoot(p))return fail("PROTECTED_ROOT");File f=SD.open(p.c_str());if(!f)return fail("NOT_FOUND");if(f.isDirectory()!=directory){f.close();return fail("WRONG_TYPE");}if(directory){File child=f.openNextFile();if(child){child.close();f.close();return fail("DIRECTORY_NOT_EMPTY");}}f.close();bool ok=directory?SD.rmdir(p.c_str()):SD.remove(p.c_str());if(ok)media.markDirty(p);return ok||fail("DELETE_FAILED");}
bool rename(const String& path,const String& dest,SyncTransport who){String p,q;if(!gate(who)||active||!canonical(path,p)||!canonical(dest,q))return false;if(protectedRoot(p)||protectedRoot(q))return fail("PROTECTED_ROOT");if(SD.exists(q.c_str()))return fail("ALREADY_EXISTS");if(!SD.exists(p.c_str()))return fail("NOT_FOUND");if(q.startsWith(p+"/"))return fail("INVALID_PATH");bool ok=SD.rename(p.c_str(),q.c_str());if(ok){media.markDirty(p);media.markDirty(q);}return ok||fail("RENAME_FAILED");}
void recover(){
 if(!media.sdOK()||active)return;
 if(SD.exists(JOURNAL))media.markDirty();

 if(SD.exists(JOURNAL)){File j=SD.open(JOURNAL);String p=j?j.readStringUntil('\n'):String();if(j)j.close();p.trim();String checked;if(!canonical(p,checked,p=="/MonoPod/theme.mpt"))return;
  if(SD.exists(BACKUP)){if(SD.exists(p.c_str())){if(!SD.remove(BACKUP))return;}else if(!SD.rename(BACKUP,p.c_str()))return;}
  if(!SD.exists(BACKUP))SD.remove(JOURNAL);
 }
 SD.remove(PART);
}
bool begin(const String& path,uint32_t size,uint32_t crc,bool replace,bool theme,SyncTransport who){
 if(!gate(who))return false;if(active)return fail("TRANSFER_ACTIVE");String p;if(!canonical(path,p,theme))return false;
 if(theme && p!="/MonoPod/theme.mpt")return fail("INVALID_THEME_PATH");if(p=="/"||size>1073741824UL|| (theme&&size>ThemeManager::MAX_BYTES+44))return fail("INVALID_SIZE");
 recover();if(SD.exists(BACKUP)||SD.exists(JOURNAL))return fail("RECOVERY_PENDING");
 if(SD.exists(p.c_str())){File f=SD.open(p.c_str());bool dir=f&&f.isDirectory();if(f)f.close();if(dir)return fail("IS_DIRECTORY");if(!replace)return fail("ALREADY_EXISTS");}
 uint64_t total=media.totalBytes(),used=media.usedBytes();if(total<used||total-used<(uint64_t)size+4096)return fail("NO_SPACE");
 int slash=p.lastIndexOf('/');String parent=slash>0?p.substring(0,slash):"/";
 if(theme && !SD.exists("/MonoPod"))SD.mkdir("/MonoPod");
 if(!SD.exists(parent.c_str()))return fail("PARENT_NOT_FOUND");
 SD.remove(PART);output=SD.open(PART,FILE_WRITE);if(!output)return fail("OPEN_FAILED");
 target=p;expected=size;checksum=crc;received=0;runningCRC=~0u;active=true;isTheme=theme;lastWrite=millis();
 transferStartedMs=millis();writeTimeUs=crcTimeUs=flushTimeUs=0;sdWriteCalls=0;
 initWriteBuffer();return true;
}
bool write(const uint8_t* data,size_t n){if(!active)return fail("NO_TRANSFER");if(n>1073741824UL-received||(n>expected-received)|| (isTheme && received+n>ThemeManager::MAX_BYTES+44))return fail("INVALID_SIZE");
 if(n && !bufferedWrite.append(data,n,[](const uint8_t* p,size_t len){return timedSdWrite(p,len);}))return fail("SD_WRITE");
 const uint32_t started=micros();
 runningCRC=crcStep(runningCRC,data,n);
 crcTimeUs+=(uint32_t)(micros()-started);
 received+=n;lastWrite=millis();return true;}
void abort(){
 if(active)reportTransfer("ABORT");
 if(output)output.close();
 freeWriteBuffer();
 if(active)SD.remove(PART);
 active=false;target="";
}
bool busy(){return active;}
void tick(){if(active && (uint32_t)(millis()-lastWrite)>15000){abort();error="TIMEOUT";}}
bool commit(){
 if(!active)return fail("NO_TRANSFER");
 // Cached data must be on SD before verifying length/CRC or renaming file.
 if(!flushPending()){abort();return fail("SD_WRITE");}
 const uint32_t flushedAt=micros();
 output.flush();flushTimeUs+=(uint32_t)(micros()-flushedAt);
 output.close();
 reportTransfer("RECEIVED");
 freeWriteBuffer();
 File verified=SD.open(PART,FILE_READ);bool validSize=verified && verified.size()==received;if(verified)verified.close();if(!validSize){abort();return fail("SD_SIZE_MISMATCH");}
 if(received!=expected || ~runningCRC!=checksum){abort();return fail("SIZE_OR_CRC_MISMATCH");}
 if(isTheme&&!ThemeManager::validate(PART)){abort();return fail("INVALID_THEME_OR_CRC");}
 String dest=target;bool old=SD.exists(dest.c_str()),installTheme=isTheme;
 File j=SD.open(JOURNAL,FILE_WRITE);if(!j){abort();return fail("JOURNAL_WRITE");}j.println(dest);j.flush();j.close();
 if(old&&!SD.rename(dest.c_str(),BACKUP)){SD.remove(JOURNAL);abort();return fail("BACKUP_RENAME");}
 if(!SD.rename(PART,dest.c_str())){if(old)SD.rename(BACKUP,dest.c_str());if(!SD.exists(BACKUP))SD.remove(JOURNAL);abort();return fail("COMMIT_FAILED");}
 active=false;target="";media.markDirty(dest,checksum);
 if(installTheme&&!display.reloadTheme()){
  SD.remove(dest.c_str());if(old)SD.rename(BACKUP,dest.c_str());display.reloadTheme();if(!SD.exists(BACKUP))SD.remove(JOURNAL);return fail("THEME_ACTIVATION_FAILED");
 }
 if(old&&!SD.remove(BACKUP))return fail("BACKUP_CLEANUP_PENDING");
 if(!SD.remove(JOURNAL))return fail("JOURNAL_CLEANUP_PENDING");return true;
}
}

