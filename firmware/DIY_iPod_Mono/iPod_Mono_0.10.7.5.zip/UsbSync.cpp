#include "UsbSync.h"
#include "SyncFiles.h"
#include "Library.h"
#include "UI.h"
#include "Settings.h"
#include "IpodIdentity.h"
#include "WiFiSync.h"
#include "ClockService.h"
#include "ClockConfigValidation.h"
#include "MonoPodDB.h"
#include <errno.h>
UsbSyncService usbSync;
#if FEATURE_USB_SYNC
namespace {
bool uintArg(const String& s,uint32_t& v,int base=10){if(s.isEmpty()||s.length()>10)return false;for(size_t i=0;i<s.length();i++)if(base==10? !isdigit((unsigned char)s[i]):!isxdigit((unsigned char)s[i]))return false;errno=0;char* end;unsigned long n=strtoul(s.c_str(),&end,base);if(errno||*end)return false;v=n;return true;}
String token(const String& s,int& i){if(i>=(int)s.length())return "";int end=s.indexOf(' ',i);if(end<0)end=s.length();String t=s.substring(i,end);i=end+1;return t;}
}
void UsbSyncService::begin(){line.reserve(700);SyncFiles::recover();}
void UsbSyncService::reply(const String& s){Serial.print("MPOD1 ");Serial.println(s);}
void UsbSyncService::fail(const char* why){SyncFiles::abort();sending=false;buffered=chunkRemaining=0;line="";discard=true;quietUntil=millis()+1500;reply(String("ERR ")+why);}
void UsbSyncService::finish(){if(buffered&&!SyncFiles::write(buffer,buffered)){fail(SyncFiles::error.c_str());return;}buffered=0;sending=false;if(!SyncFiles::commit()){String error=SyncFiles::error;SyncFiles::abort();reply("ERR "+error);return;}reply("OK SAVED");}
void UsbSyncService::command(const String& cmd){
 if(cmd=="MPOD1 HELLO"){reply(String("READY 4 SD=")+(media.sdOK()?"1":"0"));return;}
 if(cmd=="MPOD1 X INFO"||cmd=="MPOD1 X STORAGE"){reply("OK "+SyncFiles::info());return;}
 if(cmd=="MPOD1 SYNC START"){if(!media.sdOK()){reply("ERR NO_SD");return;}reply(syncMode.enter(SyncTransport::UsbCdc)?"OK SYNC_STARTED":"ERR SYNC_BUSY");return;}
 if(cmd=="MPOD1 SYNC END"){if(sending||SyncFiles::busy()){reply("ERR TRANSFER_ACTIVE");return;}if(!syncMode.is(SyncTransport::UsbCdc)){reply("ERR NO_USB_SYNC");return;}media.rescan(true);syncMode.leave(SyncTransport::UsbCdc);ui.begin();reply("OK SYNC_ENDED");return;}
 if(!SyncFiles::gate(SyncTransport::UsbCdc)){reply("ERR "+SyncFiles::error);return;}
 if(cmd.startsWith("MPOD1 X CLOCK ")){
  int p=14;String epochText=token(cmd,p),tzText=token(cmd,p),ntpText=token(cmd,p),serverText=token(cmd,p);
  uint32_t epoch=0,enabled=0;
  if(!uintArg(epochText,epoch)||epoch<1600000000UL||epoch>4102444800UL||tzText.length()>126 ||
     !uintArg(ntpText,enabled)||enabled>1){reply("ERR CLOCK_ARGUMENTS");return;}
  String tz=SyncFiles::fromHex(tzText);
  String ntpServer=clockService.ntpServer();
  if(serverText.length()){
    ntpServer="";
    if(!(serverText.length()%2)&&serverText.length()<=506){
      for(size_t i=0;i<serverText.length();i+=2){
        auto digit=[](char c)->int {if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};
        int hi=digit(serverText[i]),lo=digit(serverText[i+1]);
        if(hi<0||lo<0||!(hi*16+lo)||hi*16+lo>127){ntpServer="";break;}
        ntpServer+=(char)(hi*16+lo);
      }
    }
  }
  if(!ClockConfigValidation::timezone(tz.c_str())||!ClockConfigValidation::ntpServer(ntpServer.c_str())||
     !clockService.setTimezone(tz)||!clockService.setNtpServer(ntpServer)||!clockService.setNtpEnabled(enabled==1)){
    reply("ERR CLOCK_TIMEZONE");return;
  }
  clockService.setUnix((time_t)epoch);
  reply("OK CLOCK_SET");return;
 }
 if(cmd=="MPOD1 SCAN"){if(SyncFiles::busy()){reply("ERR TRANSFER_ACTIVE");return;}media.rescan(true);reply("OK SCANNED "+String((unsigned)media.size()));return;}
 if(cmd=="MPOD1 X DBINFO"){
  reply(String("OK {\"schema\":1,\"generation\":")+String(media.generation())+
    ",\"count\":"+String((unsigned)media.size())+",\"size\":"+String(MonoPodDB::dbSize())+
    ",\"dirty\":"+(media.dirty()?"true":"false")+"}");return;
 }
 if(cmd=="MPOD1 X DBREFRESH"){
  if(SyncFiles::busy()){reply("ERR TRANSFER_ACTIVE");return;}
  media.rescan(true);
  if(media.dirty())reply("ERR DB_WRITE_FAILED");
  else reply(String("OK GENERATION ")+String(media.generation()));return;
 }
 if(cmd.startsWith("MPOD1 X DBREAD ")){
  if(media.dirty()||!media.indexReady()){reply("ERR DB_STALE_REFRESH_REQUIRED");return;}
  int pos=15;uint32_t offset=0,count=0;
  if(!uintArg(token(cmd,pos),offset)||!uintArg(token(cmd,pos),count)||count>1024){reply("ERR INVALID_RANGE");return;}
  size_t got=0;if(!MonoPodDB::read(offset,buffer,count,got)){reply("ERR DB_READ");return;}
  reply("DATA "+String(got)+" "+MonoPodDB::hex32(~MonoPodDB::crcStep(~0u,buffer,got)));
  Serial.write(buffer,got);return;
 }
 if(cmd.startsWith("MPOD1 X ")){
  int i=8;String op=token(cmd,i),path=SyncFiles::fromHex(token(cmd,i));
  if(op=="SMOOTH"){String value=cmd.substring(15);if(value!="0" && value!="1"){reply("ERR ARGUMENTS");return;}settings.data.fontSmoothing=(value=="1");settings.markDirty();reply("OK SMOOTHING");return;}
  if(op=="LIST"){uint32_t off=0,limit=0;if(!uintArg(token(cmd,i),off)||!uintArg(token(cmd,i),limit)||limit>32){reply("ERR ARGUMENTS");return;}String result=SyncFiles::list(path,off,limit,SyncTransport::UsbCdc);reply(result.length()?"OK "+result:"ERR "+SyncFiles::error);return;}
  if(op=="STAT"||op=="META"||op=="THEMEINFO"){String result=SyncFiles::stat(op=="THEMEINFO"?"/MonoPod/theme.mpt":path,SyncTransport::UsbCdc);reply(result.length()?"OK "+result:"ERR "+SyncFiles::error);return;}
  if(op=="READ"||op=="GET"){uint32_t off=0,count=0;if(!uintArg(token(cmd,i),off)||!uintArg(token(cmd,i),count)||count>1024){reply("ERR ARGUMENTS");return;}size_t got=0;if(!SyncFiles::read(path,off,buffer,count,got,SyncTransport::UsbCdc)){reply("ERR "+SyncFiles::error);return;}char crc[9];snprintf(crc,sizeof(crc),"%08lX",(unsigned long)~SyncFiles::crcStep(~0u,buffer,got));reply("DATA "+String(got)+" "+crc);Serial.write(buffer,got);return;}
  if(op=="MKDIR"||op=="DELETE"||op=="RMDIR"||op=="RENAME"){
   bool ok=op=="MKDIR"?SyncFiles::mkdir(path,SyncTransport::UsbCdc):op=="RENAME"?SyncFiles::rename(path,SyncFiles::fromHex(token(cmd,i)),SyncTransport::UsbCdc):SyncFiles::remove(path,op=="RMDIR",SyncTransport::UsbCdc);reply(ok?"OK DONE":"ERR "+SyncFiles::error);return;
  }
  if(op=="PUT"||op=="THEME"){
   uint32_t n=0,crc=0,replace=0;String len=token(cmd,i),crcText=token(cmd,i),rep=token(cmd,i);
   if(!uintArg(len,n)||crcText.length()!=8||!uintArg(crcText,crc,16)||!uintArg(rep,replace)||replace>1){reply("ERR ARGUMENTS");return;}
   if(!SyncFiles::begin(path,n,crc,replace,op=="THEME",SyncTransport::UsbCdc)){reply("ERR "+SyncFiles::error);return;}
   size=n;received=0;buffered=0;sending=true;lastByteAt=millis();chunkRemaining=min((uint32_t)sizeof(buffer),size);if(!size){finish();return;}reply("NEXT "+String(chunkRemaining));return;
  }
  reply("ERR UNKNOWN_COMMAND");return;
 }
 reply("ERR UNKNOWN_COMMAND");
}
void UsbSyncService::loop(){
 if(sending && (!Serial || (uint32_t)(millis()-lastByteAt)>15000)){fail("TIMEOUT_OR_DISCONNECT");return;}
 uint16_t budget=1024;while(budget-- && Serial.available()){
  int c=Serial.read();if(c<0)break;
  if(discard){quietUntil=millis()+1500;continue;}
  if(sending){buffer[buffered++]=(uint8_t)c;received++;chunkRemaining--;lastByteAt=millis();if(!chunkRemaining){if(!SyncFiles::write(buffer,buffered)){fail(SyncFiles::error.c_str());return;}buffered=0;if(received==size)finish();else{chunkRemaining=min((uint32_t)sizeof(buffer),size-received);reply("NEXT "+String(chunkRemaining));}}}
  else if(c=='\n'){String cmd=line;line="";if(cmd.startsWith("MPOD1 "))command(cmd);}
  else if(c!='\r'){if(line.length()>=700){line="";discard=true;quietUntil=millis()+1500;reply("ERR LINE_TOO_LONG");}else line+=(char)c;}
 }
 if(discard && (int32_t)(millis()-quietUntil)>=0){discard=false;line="";}
}
#endif

