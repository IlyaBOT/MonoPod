# MonoPod Desktop 1.1.1

Native C# / .NET 8 Windows Forms client for MonoPod. No Python, browser engine or web UI is used at runtime.

Open `MonoPod.Desktop.sln` in Visual Studio 2022 17.8 or later (17.14 tested). Start project: `MonoPod.Desktop`. Windows 10/11 x64.

```powershell
dotnet restore
dotnet build -c Release
dotnet test -c Release
dotnet publish -c Release -r win-x64 --self-contained true
```

Portable application: `publish\win-x64\MonoPod.Desktop.exe`. Keep all files in that directory together. The self-contained output includes the .NET runtime. Build tools can use .NET SDK 8 or a newer compatible SDK; the app targets .NET 8.

Firmware compatibility for this update was checked against `..\MonoPod_v0.10.6\DIY_iPod_Mono`, MPOD1 v4. Desktop 1.1 fixes the dedicated HTTP theme endpoint, Sync session state, USB recovery and asynchronous theme generation. Firmware and Legacy Studio sources were preserved. The old `firmware-builds` and 1.0 reports describe the earlier firmware revision; they are not firmware 0.10.6 builds. No device was flashed or tested in this update.

Features: USB CDC MPOD1 v4 / local Wi-Fi HTTP; paginated microSD explorer; streaming verified transfers and atomic replacement; Unicode paths; music metadata in independent columns; MPT1/MPT2 theme editor and 160×128 preview; upload queue; cancellation; JSON preferences; exportable log. Older firmware is capability-limited and displays Unsupported for unavailable operations.

- [USB BAV timeout hotfix 1.1.1](docs/BAV_USB_FIX_RU.md)
- [Desktop 1.1 changes and validation](docs/RELEASE_1.1_RU.md)
- [Historical Desktop 1.0 report](docs/FINAL_REPORT_RU.md)
- [User guide](docs/USER_GUIDE_RU.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Protocol and MPT byte layout](docs/PROTOCOL.md)
- [Build instructions](docs/BUILD.md)
- [Verification and hardware checklist](docs/VALIDATION_RU.md)

`Legacy/Studio` contains the latest original Python Studio; `Legacy/Studio_v0.9.0` preserves the initially found reference. They are development references and are not part of the published application.
