﻿MonoPod Desktop 1.1 (1.1.0 / MPOD1 v4 / firmware 0.10.6)

Распакуйте ВСЕ файлы архива в одну папку и запустите MonoPod.Desktop.exe.
.NET runtime включён. Устанавливать Python или .NET отдельно не требуется.

USB: Native USB CDC, не диагностический USB-UART; Connect → Start Sync.
Wi-Fi: сначала включите Wi-Fi Sync на плеере, затем укажите его адрес.
Themes → Upload Theme. После установки Sync остаётся активным.
Для завершения работы нажмите End Sync или Disconnect.

Детали: docs/USER_GUIDE_RU.md и docs/RELEASE_1.1_RU.md.
Проверки: 108 тестов Desktop, 9 проверок реального загрузчика тем 0.10.6,
запуск portable при масштабах 1 / 1.25 / 1.5. Физический плеер не тестировался.
Пользовательские настройки остаются в %AppData%/MonoPod/Desktop.
